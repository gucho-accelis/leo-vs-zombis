# Alex — segundo personaje

## Instalación
Sube la carpeta `alex` a `public/sprites/characters/` desde GitHub
(Add file -> Upload files -> arrastra la carpeta entera).

## Escala — importante
Alex está **ya escalado a 0,90x la altura de Leo** dentro del lienzo común.
Leo mide 393 px en el lienzo; Alex, 353.

El motor NO debe aplicarle ninguna escala distinta: los dos comparten
lienzo de 420x440 con la línea de suelo en y=418, así que se dibujan igual.
Si escalas a Alex aparte, romperás la relación de alturas.

## Contenido
run_0..run_3, idle, aim, fire, hurt   (8 poses)

Falta: victoria y el súper (chut de fútbol). Van en hojas aparte.

## Carrera
Igual que con Leo, el frame 3 NO es el espejo del 1: solo difieren un 17,2%,
así que el ciclo completo patina. Apertura de pies por frame:

    run_0: 172 px   run_1: 0 px   run_2: 176 px   run_3: 99 px

SECUENCIA ELEGIDA: run_3 -> run_1 -> run_0 (la "421"), a 10 fps.
Es la misma que gano con Leo. run_2 no se usa.

## Diferencia de juego frente a Leo
Alex lleva rifle bláster: disparo rápido y flojo.
Leo lleva pistola: disparo lento y fuerte.
Su súper será un chut de fútbol, no el Murasaki.
